ssre.sw <- function(X, sigma.e.tilde = sqrt(0.5), sigma.e = sqrt(0.5),
                    sigma.c.tilde = sqrt(0.02), sigma.c = sqrt(0.02),
                    alpha = 0.05, beta = 0.1, delta = 0.2, tau = 0,
                    pi = rep(0, ncol(X)), lambda.L = 1, n.max = 200, t = 1,
                    blinded = TRUE, correction = 0, REML = TRUE,
                    parallel = TRUE, cpus = 8, replicates = 10000,
                    summary = TRUE){

  ##### ERROR CHECKING ########################################################

  if (!is.matrix(X) | ncol(X) == 1 | nrow(X) == 1 | !all(X %in% c(0, 1))){
    stop("X must be an indicator matrix with at least 2 rows and 2 columns.")
  }
  if (sigma.e.tilde <= 0){
      stop("Assumed within person standard deviation sigma.e must be strictly positive.")
  }
  if (sigma.e <= 0){
    stop("Within person standard deviation sigma.e must be strictly positive.")
  }
  if (sigma.c.tilde <= 0){
    stop("Assumed between cluster standard deviation sigma.e must be strictly positive.")
  }
  if (sigma.c <= 0){
    stop("Assumed between cluster standard deviation sigma.e must be strictly positive.")
  }
  if ((alpha <= 0) | (alpha >= 1)){
    stop("Type-I error rate alpha must be strictly between 0 and 1.")
  }
  if ((beta <= 0) | (beta >= 1)){
    stop("Type-II error rate beta must be strictly between 0 and 1.")
  }
  if (delta <= 0){
    stop("Clinically relevant difference delta to power for must be strictly positive.")
  }
  if (!is.numeric(tau)){
    stop("True treatment effect tau must be numeric.")
  }
  if (!is.vector(pi) | (length(pi) != ncol(X))){
    stop("pi must be a vector of length ncol(X).")
  }
  if (lambda.L <= 0){
    stop("lambda.L must be strictly positive.")
  }
  if ((n.max%%1 != 0) | (n.max < 2)){
    stop("n.max must be a whole number greater than or equal to 2.")
  }
  if (!(t %in% 1:ncol(X))){
    stop("t must be in 1:ncol(X).")
  }
  if (!is.logical(blinded)){
    stop("blinded must be set to TRUE or FALSE.")
  }
  if (!is.numeric(correction)){
    stop("correction must be numeric.")
  }
  if (!is.logical(REML)){
    stop("REML must be logical.")
  }
  if (!is.logical(parallel)){
    stop("parallel must be set to TRUE or FALSE.")
  }
  if ((cpus%%1 != 0) | (cpus < 1)){
    stop("cpus must be a whole number greater than or equal to 1.")
  }
  if ((replicates%%1 != 0) | (replicates < 1)){
    stop("replicates must be a whole number greater than or equal to 1.")
  }
  if (!is.logical(summary)){
    stop("summary must be set to TRUE or FALSE.")
  }

  ##### FUNCTION INITIALISATION ###############################################

  reestnFinder <- function(n.new, n.old, C, Ti, t, delta, beta, est.sigma.e,
                           est.sigma.c, X.des.mats, diag.mats, one.mats){
    N.T              <- n.old*C*t + n.new*C*(Ti - t)
    X.des            <- X.des.mats[[n.new]]
    Sigma.c.inv      <- diag.mats[[n.new]]/(est.sigma.e^2) -
      ((est.sigma.c^2)/(est.sigma.e^2 + (est.sigma.c*est.sigma.e)^2*(N.T/C)))*
      one.mats[[n.new]]
    XT.Sigma.inv.X   <- matrix(0, nrow = Ti + 1, ncol = Ti + 1)
    for (i in 1:C){
      XT.Sigma.inv.X <- XT.Sigma.inv.X + t(X.des[[i]])%*%Sigma.c.inv%*%X.des[[i]]
    }
    Covariance       <- ginv(as.matrix(XT.Sigma.inv.X))
    I                <- 1/Covariance[Ti + 1, Ti + 1]
    PR               <- pt(q = qt(1 - alpha, df = N.T - C - Ti),
                           ncp = delta*sqrt(I), df = N.T - C - Ti,
                           lower.tail = FALSE)
    Score            <- PR - (1 - beta)
    return(Score)
  }

  informationCRCT <- function(n, X, t, sigma.e, sigma.c){
    if (length(t) == 1 && t == 1){
      C      <- length(X)
      sigma2 <- sigma.e^2/n
      U <- sum(X)
      V <- sum(X^2)
      W <- sum(X)^2
      I <- ((C*U - W)*sigma2 + (U^2 + C*U - W - C*V)*sigma.c^2)/
        (C*sigma2*(sigma2 + sigma.c^2))
    } else {
      C      <- nrow(X)
      sigma2 <- sigma.e^2/n
      I      <- numeric(length(t))
      for (i in 1:length(t)){
        U    <- sum(X[, 1:t[i]])
        if (t[i] > 1){
          V  <- sum(rowSums(X[, 1:t[i]])^2)
          W  <- sum(colSums(X[, 1:t[i]])^2)
        } else {
          V  <- sum(X[, t[i]]^2)
          W  <- sum(X[, t[i]])^2
        }
        I[i] <- ((C*U - W)*sigma2 + (U^2 + C*t[i]*U - t[i]*W - C*V)*sigma.c^2)/
          (C*sigma2*(sigma2 + t[i]*sigma.c^2))
      }
    }
    return(I)
  }

  nCRCT <- function(n, X, delta, alpha, beta, sigma.e, sigma.c){
    I     <- informationCRCT(n, X, ncol(X), sigma.e, sigma.c)
    PnotR <- pt(q = qt(1 - alpha, df = n*nrow(X)*ncol(X) - nrow(X) - ncol(X)),
                ncp = delta*sqrt(I),
                df = n*nrow(X)*ncol(X) - nrow(X) - ncol(X))
    Score <- (beta - PnotR)^2
    return(Score)
  }

  singleTrial <- function(rep, n){
    response  <- numeric(C*t*n)
    period    <- periods[[1]]
    treatment <- treatments[[1]]
    cluster   <- clusters[[1]]
    mean      <- means[[1]]
    for (c in 1:C){
      response[(1 + (c - 1)*t*n):(c*t*n)]  <- as.numeric(rnorm(n*t)%*%chol.Sigma.22) +
                                                mean[(1 + (c - 1)*t*n):(c*t*n)]
    }
    if (t < Ti){
      if (blinded == TRUE){
        N.t         <- n*C*t
        S.Ct.2      <- 0
        for (i in 1:C){
          for (j in 1:t){
            S.Ct.2  <- S.Ct.2 + sum((response[(1 + (c - 1)*t*n + (j - 1)*n):((c - 1)*t*n + j*n)] -
                                       mean(response[(1 + (c - 1)*t*n + (j - 1)*n):((c - 1)*t*n + j*n)]))^2)
          }
        }
        S.Ct.2      <- (1/(N.t - C*t))*S.Ct.2
        S.1.2       <- (1/(N.t - 1))*sum((response - mean(response))^2)
        est.sigma.e  <- sqrt(S.Ct.2)
        if (S.1.2 >= est.sigma.e^2 + factor.2){
          est.sigma.c  <- sqrt(((C*(N.t - 1))/(N.t*(C - 1)))*(S.1.2 - est.sigma.e^2 - factor.2))
        } else if (S.1.2 >= est.sigma.e^2) {
          est.sigma.c  <- sqrt(((C*(N.t - 1))/(N.t*(C - 1)))*(S.1.2 - est.sigma.e^2))
        } else {
          est.sigma.c  <- 0
        }
      } else {
        df.analysis <- data.frame(Period = period, Cluster = cluster,
                                  Treatment = treatment, Response = response)
        if (t == 1 && sum(X[, 1:t]) == 0){
          interim.analysis <- lmer(Response ~ (1 | Cluster), data = df.analysis,
                                   REML = REML)
        } else if (t == 1 && sum(X[, 1:t]) != 0){
          interim.analysis <- lmer(Response ~ Treatment + (1 | Cluster),
                                   data = df.analysis, REML = REML)
        } else if (t != 1 && sum(X[, 1:t]) == 0){
          interim.analysis <- lmer(Response ~ Period + (1 | Cluster),
                                   data = df.analysis, REML = REML)
        } else {
          interim.analysis <- lmer(Response ~ Period + Treatment + (1 | Cluster),
                                   data = df.analysis, REML = REML)
        }
        est.sigma.c        <- sqrt(VarCorr(interim.analysis)[[1]][1])
        est.sigma.e        <- sigma(interim.analysis)
      }
      Under.P   <- 0
      Over.P    <- 0
      f.n.min   <- reestnFinder(n.min, n, C, Ti, t, delta, beta, est.sigma.e,
                                est.sigma.c, X.des.mats, diag.mats, one.mats)
      if (f.n.min >= 0){
        reest.n <- n.min
        Over.P  <- 1
      } else {
        f.n.max <- reestnFinder(n.max, n, C, Ti, t, delta, beta, est.sigma.e,
                                est.sigma.c, X.des.mats, diag.mats, one.mats)
        if (f.n.max > 0){
          a     <- n.min
          b     <- n.max
          fa    <- f.n.min
          fb    <- f.n.max
          check <- 0
          while ((b - a) > 1){
            c  <- ceiling((a + b)/2)
            fc <- reestnFinder(c, n, C, Ti, t, delta, beta, est.sigma.e,
                               est.sigma.c, X.des.mats, diag.mats, one.mats)
            if (fc == 0){
              check <- 1
              break
            } else {
              if (((fa < 0) && (fc < 0)) || ((fa > 0) & (fc > 0))) {
                a  <- c
                fa <- fc
              } else {
                b  <- c
                fb <- fc
              }
            }
          }
          if (check == 0){
            reest.n <- b
          } else {
            reest.n <- c
          }
        } else {
          reest.n   <- n.max
          Under.P   <- 1
        }
      }
      response.2   <- numeric(C*(Ti - t)*reest.n)
      period       <- periods[[2]][[reest.n]]
      treatment    <- treatments[[2]][[reest.n]]
      cluster      <- clusters[[2]][[reest.n]]
      mean.2       <- means[[2]][[reest.n]]
      for (c in 1:C){
        response.2[(1 + (c - 1)*(Ti - t)*reest.n):(c*(Ti - t)*reest.n)] <- as.numeric(rnorm((Ti - t)*reest.n)%*%chol.Sigma.c.bar.mats[[reest.n]] + mean.2[[c]] + t(Sigma.fact.mats[[reest.n]]%*%
                                                                                                                                                                     (response[(1 + (c - 1)*n*t):(n*t*c)] - mean[(1 + (c - 1)*n*t):(n*t*c)])))
      }
      response     <- c(response, response.2)
    } else {
      reest.n      <- 0
      Under.P      <- 0
      Over.P       <- 0
    }
    df.analysis    <- data.frame(Period = period, Cluster = cluster,
                                 Treatment = treatment,
                                 Response = response)
    final.analysis <- lmer(Response ~ Period + Treatment + (1 | Cluster),
                           data = df.analysis, REML = REML)
    f.est.sigma.c  <- sqrt(VarCorr(final.analysis)[[1]][1])
    f.est.sigma.e  <- sigma(final.analysis)
    if (t == Ti){
      est.sigma.c  <- f.est.sigma.c
      est.sigma.e  <- f.est.sigma.e
    }
    tr.eff   <- fixef(final.analysis)[names(fixef(final.analysis)) == "Treatment"]
    pos      <- nrow(vcov(final.analysis))
    I.tr     <- 1/vcov(final.analysis)[pos, pos]
    Z        <- tr.eff*sqrt(I.tr)
    N        <- n*C*t + reest.n*C*(Ti - t)
    e        <- qt(1 - alpha, df = N - C - Ti)
    if (Z > e){
      Reject <- 1
    } else {
      Reject <- 0
    }
    output   <- c(Reject, N, Under.P, Over.P, est.sigma.c, est.sigma.e,
                  f.est.sigma.c, f.est.sigma.e)
    return(output)
  }

  wrapper <- function(rep){
    result <- singleTrial(rep, n.sw)
    return(result)
  }

  componentsN <- function(n){
    X.des <- list()
    n.vec <- c(rep(n.sw, t), rep(n, Ti - t))
    pers  <- rbind(rep(0, Ti - 1), diag(1, Ti - 1, Ti - 1))
    for (c in 1:C){
      count      <- 1
      X.des[[c]] <- matrix(0, nrow = n.sw*t + n*(Ti - t), ncol = Ti + 1)
      for (k in 1:Ti){
        for (j in 1:n.vec[k]){
          X.des[[c]][count, ] <- c(1, pers[k, ], X[c, k])
          count <- count + 1
        }
      }
    }
    X.des.mats.ret <- X.des
    diag.mats.ret  <- Diagonal(n.sw*t + n*(Ti - t))
    one.mats.ret   <- as(matrix(1, nrow = n.sw*t + n*(Ti - t),
                                ncol = n.sw*t + n*(Ti - t)), "dspMatrix")

    period.c        <- numeric((Ti - t)*n)
    for (j in 1:(Ti - t)){
      period.c[(1 + (j - 1)*n):(j*n)] <- rep(j + t, n)
    }
    periods.ret  <- c(periods[[1]], rep(period.c, C))
    treatment.2  <- numeric(C*(Ti - t)*n)
    cluster.2    <- numeric(C*(Ti - t)*n)
    mean.2       <- list()
    for (c in 1:C){
      treatment.c <- numeric(n*(Ti - t))
      mean.c      <- numeric(n*(Ti - t))
      for (j in 1:(Ti - t)){
        treatment.c[(1 + (j - 1)*n):(j*n)] <- rep(X[c, j + t], n)
        mean.c[(1 + (j - 1)*n):(j*n)]      <- rep(tau*X[c, j + t] + pi[j + t], n)
      }
      treatment.2[(1 + (c - 1)*(Ti - t)*n):(c*(Ti - t)*n)] <- treatment.c
      cluster.2[(1 + (c - 1)*(Ti - t)*n):(c*(Ti - t)*n)]   <- rep(c, n*(Ti - t))
      mean.2[[c]]  <- mean.c
    }
    treatments.ret <- c(treatments[[1]], treatment.2)
    clusters.ret   <- c(clusters[[1]], cluster.2)
    means.ret      <- mean.2

    output      <- list()
    output[[1]] <- X.des.mats.ret
    output[[2]] <- diag.mats.ret
    output[[3]] <- one.mats.ret
    output[[4]] <- periods.ret
    output[[5]] <- treatments.ret
    output[[6]] <- clusters.ret
    output[[7]] <- means.ret
    return(output)
  }

  wrapper.2 <- function(n){
    result <- componentsN(n)
    return(result)
  }

  ##### MAIN COMPUTATIONS #####################################################

  if (summary == TRUE){
    print("Initialising all required variables...")
  }

  C     <- nrow(X)
  Ti    <- ncol(X)
  # Find required sample size of a conventional SW-CRCT design using assumed
  # variance values
  n.sw  <- suppressWarnings(optim(par = 10, fn = nCRCT, X = X,
                                  delta = delta, alpha = alpha, beta = beta,
                                  sigma.e = sigma.e.tilde,
                                  sigma.c = sigma.c.tilde)$par)
  n.sw  <- ceiling(n.sw)
  n.min <- ceiling(lambda.L*n.sw)

  X.des.mats   <- list()
  diag.mats    <- list()
  one.mats     <- list()
  Sigma.fact.mats <- list()
  chol.Sigma.c.bar.mats <- list()
  periods      <- list()
  treatments   <- list()
  clusters     <- list()
  means        <- list()
  period.c     <- numeric(t*n.sw)
  for (j in 1:t){
    period.c[(1 + (j - 1)*n.sw):(j*n.sw)] <- rep(j, n.sw)
  }
  periods[[1]] <- rep(period.c, C)
  treatment    <- numeric(C*t*n.sw)
  cluster      <- numeric(C*t*n.sw)
  mean         <- numeric(C*t*n.sw)
  for (c in 1:C){
    treatment.c <- numeric(t*n.sw)
    mean.c      <- NULL
    for (j in 1:t){
      treatment.c[(1 + (j - 1)*n.sw):(j*n.sw)] <- rep(X[c, j], n.sw)
      mean.c[(1 + (j - 1)*n.sw):(j*n.sw)]      <- rep(tau*X[c, j] + pi[j], n.sw)
    }
    treatment[(1 + (c - 1)*t*n.sw):(c*t*n.sw)] <- treatment.c
    cluster[(1 + (c - 1)*t*n.sw):(c*t*n.sw)]   <- rep(c, n.sw*t)
    mean[(1 + (c - 1)*t*n.sw):(c*t*n.sw)]      <- mean.c
  }
  treatments[[1]] <- treatment
  clusters[[1]]   <- cluster
  means[[1]]      <- mean
  periods[[2]]    <- list()
  treatments[[2]] <- list()
  clusters[[2]]   <- list()
  means[[2]]      <- list()

  Sigma.11         <- as(matrix(sigma.c^2, n.max*(Ti - t), n.max*(Ti - t)), "dspMatrix") +
    Diagonal(x = rep(sigma.e^2, n.max*(Ti - t)))
  Sigma.12         <- as(matrix(sigma.c^2, ncol = n.sw*t, nrow = n.max*(Ti - t)), "dgeMatrix")
  Sigma.22.inv     <- Diagonal(n.sw*t)/(sigma.e^2) -
    ((sigma.c^2)/(sigma.e^4 + (sigma.c*sigma.e)^2*(1 + n.sw*t)))*
    as(matrix(1, nrow = n.sw*t, ncol = n.sw*t), "dspMatrix")
  Sigma.fact       <- Sigma.12%*%Sigma.22.inv
  Sigma.c.bar      <- as(Sigma.11 - Sigma.fact%*%t(Sigma.12), "dspMatrix")
  chol.Sigma.c.bar <- matrix(0, nrow = n.max*(Ti - t), ncol = n.max*(Ti - t))
  chol.Sigma.c.bar[upper.tri(chol.Sigma.c.bar, diag = TRUE)] <- chol(Sigma.c.bar)@x
  chol.Sigma.c.bar <- as(chol.Sigma.c.bar, "dtpMatrix")
  remove(Sigma.11)
  remove(Sigma.12)
  remove(Sigma.22.inv)
  remove(Sigma.c.bar)

  sink("NULL")
  suppressMessages(sfInit(parallel = parallel, cpus = cpus))
  sfExport("n.sw", "t", "Ti", "C", "X", "tau", "pi", "sigma.c",
           "sigma.e", "periods", "treatments", "clusters", "means", "componentsN")
  suppressMessages(sfLibrary(Matrix))
  results <- sfLapply(n.min:n.max, wrapper.2)
  suppressMessages(sfStop())
  for (n in 1:(n.max - n.min + 1)){
    X.des.mats[[n + n.min - 1]]      <- results[[n]][[1]]
    diag.mats[[n + n.min - 1]]       <- results[[n]][[2]]
    one.mats[[n + n.min - 1]]        <- results[[n]][[3]]
    periods[[2]][[n + n.min - 1]]    <- results[[n]][[4]]
    treatments[[2]][[n + n.min - 1]] <- results[[n]][[5]]
    clusters[[2]][[n + n.min - 1]]   <- results[[n]][[6]]
    means[[2]][[n + n.min - 1]]      <- results[[n]][[7]]
    Sigma.fact.mats[[n + n.min - 1]] <- Sigma.fact[1:((n + n.min - 1)*(Ti - t)), ]
    chol.Sigma.c.bar.mats[[n + n.min - 1]] <- chol.Sigma.c.bar[1:((n + n.min - 1)*(Ti - t)),
                                                               1:((n + n.min - 1)*(Ti - t))]
  }
  remove(results)
  sink()

  Sigma.22 <- as(matrix(sigma.c^2, n.sw*t, n.sw*t),
                 "dspMatrix") + Diagonal(x = rep(sigma.e^2, n.sw*t))
  chol.Sigma.22 <- matrix(0, nrow = n.sw*t, ncol = n.sw*t)
  chol.Sigma.22[upper.tri(chol.Sigma.22, diag = TRUE)] <- chol(Sigma.22)@x
  chol.Sigma.22 <- as(chol.Sigma.22, "dtpMatrix")

  N.t      <- n.sw*C*t
  factor.1 <- (n.sw*correction^2/(N.t - C*t))*sum(X[, 1:t]^2) - (correction^2/(n.sw*(N.t - C*t)))*sum(X[, 1:t])^2
  factor.2 <- (n.sw*correction^2/(N.t - 1))*sum(X[, 1:t]^2) - (n.sw^2*correction^2/(N.t*(N.t - 1)))*sum(X[, 1:t])^2

  if (summary == TRUE){
    print("Determining performance of SSRE procedure...")
  }

  sink("NULL")
  suppressMessages(sfInit(parallel = parallel, cpus = cpus))
  suppressMessages(sfLibrary(lme4))
  suppressMessages(sfLibrary(stats))
  suppressMessages(sfLibrary(MASS))
  sfExport("C", "Ti", "n.sw", "alpha", "beta", "delta", "tau", "sigma.e",
           "sigma.c", "pi", "n.min", "n.max", "t", "blinded",
           "correction", "REML", "X.des.mats", "diag.mats", "one.mats",
           "periods", "treatments", "clusters", "means", "chol.Sigma.22",
           "factor.1", "factor.2", "reestnFinder", "singleTrial", "Sigma.fact.mats",
           "chol.Sigma.c.bar.mats")
  results           <- sfLapply(1:replicates, wrapper)
  suppressMessages(sfStop())
  sink()
  results           <- matrix(unlist(results), nrow = replicates, ncol = 8, byrow = TRUE)
  colnames(results) <- c("Reject", "N", "Under.P",
                         "Over.P", "est.sigma.c", "est.sigma.e",
                         "f.est.sigma.c", "f.est.sigma.e")
  av.results        <- c(alpha, beta, delta, sigma.e.tilde, sigma.c.tilde, n.sw, tau, sigma.e,
                         sigma.c, pi, n.min, n.max, t, as.numeric(blinded), correction,
                         as.numeric(REML), replicates, colMeans(results))
  names(av.results) <- c("alpha", "beta", "delta", "sigma.e.tilde", "sigma.c.tilde",
                         "n.sw", "tau", "sigma.e", "sigma.c",
                         paste("pi", 1:Ti, sep = ""), "n.min", "n.max", "t",
                         "blinded", "correction", "REML", "replicates",
                         "Reject", "N", "Under.P", "Over.P", "est.sigma.c", "est.sigma.e",
                         "f.est.sigma.c", "f.est.sigma.e")

  if (summary == TRUE){
    print("Outputting...")
  }

  output            <- list(alpha = alpha, av.results = av.results, beta = beta,
                            blinded = blinded, correction = correction,
                            cpus = cpus, delta = delta, lambda.L = lambda.L,
                            n.max = n.max, parallel = parallel, pi = pi,
                            REML = REML, replicates = replicates, results = results,
                            sigma.c = sigma.c, sigma.c.tilde = sigma.c.tilde,
                            sigma.e = sigma.e, sigma.e.tilde = sigma.e.tilde,
                            t = t, tau = tau, X = X)
  return(output)
}
