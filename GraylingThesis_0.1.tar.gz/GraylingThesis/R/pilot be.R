optimal.pilot.be <- function(max.O = 400, D = 11, E.tilde = 5, max.P = 2,
                             sigma.e = sqrt(log(0.3^2 + 1)),
                             sigma.b = sqrt(2*sigma.e^2), alpha = 0.05,
                             B = log(1.25), delta = 0, pi = rep(0, D - 1),
                             REML = TRUE, t.boundaries = TRUE, max.calls = 100,
                             parallel = TRUE, cpus = 8, replicates = 1000,
                             summary = TRUE){

  ##### ERROR CHECKING ########################################################

  if ((D%%1 != 0) | (D < 2)){
    stop("D must be a whole number greater than or equal to 2.")
  }
  if ((max.P%%1 != 0) | (max.P < 2)){
    stop("max.P must be a whole number greater than or equal to 2.")
  }
  if ((max.O%%1 != 0) | (max.O < 2*max.P)){
    stop("max.O must be a whole number greater than or equal to 2*max.P.")
  }
  if (sigma.e <= 0){
    stop("Within person standard deviation sigma.e must be strictly positive.")
  }
  if (sigma.b <= 0){
    stop("Between person standard deviation sigma.e must be strictly positive.")
  }
  if ((alpha <= 0) | (alpha >= 1)){
    stop("FWER alpha must be strictly between 0 and 1.")
  }
  if (B <= 0){
    stop("BE margin B must be strictly positive.")
  }
  if (delta < 0 | delta >= B){
    stop("BE margin delta to power for must be in [0,B).")
  }
  if (!is.vector(pi) | (length(pi) != D - 1)){
    stop("pi must be a vector of length D - 1.")
  }
  if (!is.logical(REML)){
    stop("REML must be logical.")
  }
  if (!is.logical(t.boundaries)){
    stop("t.boundaries must be logical.")
  }
  if ((max.calls%%1 != 0) | (max.calls < 1)){
    stop("max.calls must be a whole number greater than or equal to 1.")
  }
  if (!is.logical(parallel)){
    stop("parallel must be set to TRUE or FALSE.")
  }
  if ((cpus%%1 != 0) | (cpus < 1)){
    stop("cpus must be a whole number greater than or equal to 1.")
  }
  if ((replicates%%1 != 0) | (replicates < 1)){
    stop("replicates must be a whole number greater than or equal to 1.")
  }
  if (!is.logical(summary)){
    stop("summary must be set to TRUE or FALSE.")
  }

  ##### FUNCTION INITIALISATION ###############################################

  # Initialise a function to simulate a single pilot trial
  singlePar <- function(parameters, max.o, D, k, max.P, alpha,
                        B, delta, pi, REML, t.boundaries, design, periods,
                        subjects, treatments, chol.Sigma.mats){

    p   <- as.numeric(parameters[1])
    r   <- as.numeric(parameters[2])
    n.1 <- floor(max.o*p/(max.P))
    o.1 <- n.1*max.P
    if (n.1 <= 1){
      return(-Inf)
    }

    work      <- sort(sample(1:(D - 1), E.tilde, FALSE))
    tau       <- rep(B, D - 1)
    tau[work] <- delta

    periods.1   <- periods[[D]][[n.1]]
    subjects.1  <- subjects[[D]][[n.1]]

    mean <- numeric(D*max.P)
    for (s in 1:D){
      mean.s           <- numeric(max.P)
      treatment.s           <- numeric(max.P)
      for (j in 1:max.P){
        treatment.s[j] <- design[s, j]
        if (j > 1){
          mean.s[j]    <- mean.s[j] + pi[j - 1]
        }
        if (treatment.s[j] != 0){
          mean.s[j]    <- mean.s[j] + tau[treatment.s[j]]
        }
      }
      mean[(1 + (s - 1)*max.P):(s*max.P)] <- mean.s
    }
    means <- rep(mean, floor(n.1/D))

    rem.1 <- n.1%%D
    if (rem.1 > 0){
      rand.sample <- sample(1:D, rem.1, FALSE)
      sequences <- design[rand.sample, ]
      extra.means      <- numeric(rem.1*max.P)
      extra.treatments <- numeric(rem.1*max.P)
      for (s in 1:rem.1){
        treatment.s      <- numeric(max.P)
        mean.s           <- numeric(max.P)
        for (p in 1:max.P){
          if (rem.1 == 1){
            treatment.s[p] <- sequences[p]
          } else {
            treatment.s[p] <- sequences[s, p]
          }
          if (p > 1){
            mean.s[p]    <- mean.s[p] + pi[p - 1]
          }
          if (treatment.s[p] != 0){
            mean.s[p]    <- mean.s[p] + tau[treatment.s[p]]
          }
        }
        extra.treatments[(1 + (s - 1)*max.P):(s*max.P)] <- treatment.s
        extra.means[(1 + (s - 1)*max.P):(s*max.P)]      <- mean.s
      }
      if (n.1 < D){
        means.1 <- extra.means
        treatments.1 <- extra.treatments
      } else {
        means.1 <- c(means, extra.means)
        treatments.1 <- c(treatments[[n.1 - rem.1]], extra.treatments)
      }

    } else {
      means.1 <- rep(means, n.1/D)
      treatments.1 <- treatments[[n.1]]
    }

    if (length(unique(treatments.1)) != D){
      return(-Inf)
    }

    responses.1 <- as.numeric(rnorm(n.1*max.P)%*%chol.Sigma.mats[[D]][[n.1]]) +
      means.1
    df.analysis <- data.frame(Period = factor(periods.1, levels = 1:D),
                              Subject = factor(subjects.1, levels = unique(subjects.1)),
                              Treatment = factor(treatments.1, levels = 0:(D - 1)),
                              Response = responses.1)
    interim.analysis <- try(lmer(Response ~ Period + Treatment + (1 | Subject),
                             data = df.analysis, REML = REML))
    if (class(interim.analysis) == "try-error"){
      return(-Inf)
    }
    beta.hat           <- fixef(interim.analysis)
    if (length(beta.hat) < max.P + D - 1){
      return(-Inf)
    }
    tau.hat            <- beta.hat[(1 + max.P):(max.P + D - 1)]
    I.hat              <- 1/diag(as.matrix(vcov(interim.analysis)))[(1 + max.P):(max.P + D - 1)]
    Z.hat.plus         <- (tau.hat + B)*sqrt(I.hat)
    Z.hat.minus        <- (tau.hat - B)*sqrt(I.hat)

    drugs.rem <- 0:(D - 1)
    decision  <- numeric(D - 1)
    new.drugs.rem <- NULL
    for (d in drugs.rem[-1]){
      if (Z.hat.plus[d] >= r & Z.hat.minus[d] <= -r){
        new.drugs.rem <- c(new.drugs.rem, d)
      }
    }
    drugs.rem <- c(0, new.drugs.rem)
    if (length(drugs.rem) == 1){
      R <- 0
      return(R)
    } else {
      rem <- length(drugs.rem)
      n.2 <- floor((max.o - o.1)/(min(max.P, rem)))
      if (n.2 <= 1){
        R <- 0
        return(R)
      }
      periods.2   <- periods[[rem]][[n.2]]
      subjects.2  <- subjects[[rem]][[n.2]]

      R <- length(drugs.rem)
      design        <- matrix(0, R, R)
      design[1, ]   <- drugs.rem
      for (i in 2:R){
        design[i, ] <- c(design[i - 1, 2:R],
                         design[i - 1, 1])
      }
      if (R > max.P){
        design <- design[, -((max.P + 1):R)]
      }
      mean <- numeric(R*min(R, max.P))
      treatment <- numeric(R*min(R, max.P))
      for (s in 1:R){
        mean.s           <- numeric(min(R, max.P))
        treatment.s           <- numeric(min(R, max.P))
        for (j in 1:min(R, max.P)){
          treatment.s[j] <- design[s, j]
          if (j > 1){
            mean.s[j]    <- mean.s[j] + pi[j - 1]
          }
          if (treatment.s[j] != 0){
            mean.s[j]    <- mean.s[j] + tau[treatment.s[j]]
          }
        }
        mean[(1 + (s - 1)*min(R, max.P)):(s*min(R, max.P))]      <- mean.s
        treatment[(1 + (s - 1)*min(R, max.P)):(s*min(R, max.P))]      <- treatment.s
      }
      means <- rep(mean, floor(n.2/R))
      treatments <- rep(treatment, floor(n.2/R))

      rem.2 <- n.2%%rem
      if (rem.2 > 0){
        rand.sample <- sample(1:rem, rem.2, FALSE)
        sequences <- design[rand.sample, ]
        extra.means      <- numeric(rem.2*min(rem, max.P))
        extra.treatments <- numeric(rem.2*min(rem, max.P))
        for (s in 1:rem.2){
          treatment.s      <- numeric(min(rem, max.P))
          mean.s           <- numeric(min(rem, max.P))
          for (p in 1:min(rem, max.P)){
            if (rem.2 == 1){
              treatment.s[p] <- sequences[p]
            } else {
              treatment.s[p] <- sequences[s, p]
            }
            if (p > 1){
              mean.s[p]    <- mean.s[p] + pi[p - 1]
            }
            if (treatment.s[p] != 0){
              mean.s[p]    <- mean.s[p] + tau[treatment.s[p]]
            }
          }
          extra.treatments[(1 + (s - 1)*min(rem, max.P)):(s*min(rem, max.P))] <- treatment.s
          extra.means[(1 + (s - 1)*min(rem, max.P)):(s*min(rem, max.P))]      <- mean.s
        }
        means.2 <- c(means, extra.means)
        treatments.2 <- c(treatments, extra.treatments)
      } else {
        means.2     <- means
        treatments.2 <- treatments
      }
      if (length(unique(treatments.2)) != R){
        return(-Inf)
      }
      responses.2 <- as.numeric(rnorm(n.2*min(R, max.P))%*%chol.Sigma.mats[[rem]][[n.2]]) +
        means.2
      df.analysis <- data.frame(Period = factor(periods.2, levels = 1:min(max.P, R)),
                                Subject = factor(subjects.2, levels = unique(subjects.2)),
                                Treatment = factor(treatments.2, levels = unique(treatments.2)),
                                Response = responses.2)
      interim.analysis <- lmer(Response ~ Period + Treatment + (1 | Subject),
                               data = df.analysis, REML = REML)
      if (class(interim.analysis) == "try-error"){
        return(-Inf)
      }
      beta.hat           <- fixef(interim.analysis)
      if (length(beta.hat) < min(max.P, R) + R - 1){
        return(-Inf)
      }
      tau.hat            <- beta.hat[(min(max.P, R) + 1):(min(max.P, R) + R - 1)]
      I.hat              <- 1/diag(as.matrix(vcov(interim.analysis)))[(min(max.P, R) + 1):(min(max.P, R) + R - 1)]
      Z.hat.plus         <- (tau.hat + B)*sqrt(I.hat)
      Z.hat.minus        <- (tau.hat - B)*sqrt(I.hat)
      if (t.boundaries == TRUE){
        c <- qt(1 - alpha/(R - 1),
                df = n.2*min(max.P, R) - n.2 - (R - 1) - (min(max.P, R) - 1))
      } else {
        c <- qnorm(1 - alpha/(R - 1))
      }
      decision  <- numeric(D - 1)
      for (d in 1:(R - 1)){
        if (Z.hat.plus[d] >= c & Z.hat.minus[d] <= -c){
          decision[drugs.rem[d + 1]] <- 1
        }
      }
      R <- sum(decision[work])
      return(R)
    }
  }

  # Initialise a function to evaluate the value of the objective function of a
  # particular design
  objFn <- function(parameters, max.o, D, E.tilde, max.P, alpha,
                    B, delta, pi, REML, t.boundaries, design, periods, subjects,
                    treatments, chol.Sigma.mats, replicates){
    reject <- numeric(replicates)
    for (i in 1:replicates){
      reject[i] <- singlePar(parameters, max.o, D, k, max.P, alpha,
                             B, delta, pi, REML, t.boundaries, design, periods, subjects,
                             treatments, chol.Sigma.mats)
    }
    ER <- mean(reject)
    return(-ER)
  }

  ##### MAIN COMPUTATIONS #####################################################

  if (summary == TRUE){
    print("Initialising all required variables...")
  }

  design        <- matrix(0, D, D)
  design[1, ]   <- 0:(D - 1)
  for (i in 2:D){
    design[i, ] <- c(design[i - 1, 2:D],
                     design[i - 1, 1])
  }
  if (D > max.P){
    design <- design[, -((max.P + 1):D)]
  }

  chol.Sigma.mats <- list()
  periods         <- list()
  subjects        <- list()
  treatments      <- list()

  for (d in 2:D){
    if (d == D){
      poss.n     <- floor((1:max.o)/min(d, max.P))
      poss.n     <- unique(poss.n)[-1]
      div.poss.n <- which(poss.n%%d == 0)
      treatment <- numeric(d*max.P)
      for (s in 1:d){
        treatment.s      <- numeric(max.P)
        for (p in 1:max.P){
          treatment.s[p] <- design[s, p]
        }
        treatment[(1 + (s - 1)*max.P):(s*max.P)]   <- treatment.s
      }
      treatments[[div.poss.n[length(div.poss.n)]]] <- rep(treatment, floor(div.poss.n[length(div.poss.n)]/d))
    }

    chol.Sigma.mats[[d]] <- list()
    periods[[d]]         <- list()
    subjects[[d]]        <- list()
    poss.n               <- floor((1:max.o)/min(d, max.P))
    poss.n               <- unique(poss.n)[-1]

    Sigma.mat            <- matrix(0, poss.n[length(poss.n)]*min(d, max.P),
                                   poss.n[length(poss.n)]*min(d, max.P))
    Sigma.block          <- matrix(sigma.b^2, min(d, max.P), min(d, max.P)) +
                              diag(sigma.e^2, min(d, max.P), min(d, max.P))
    subject              <- numeric(poss.n[length(poss.n)]*min(d, max.P))
    for (i in 1:poss.n[length(poss.n)]){
      Sigma.mat[(1 + (i - 1)*min(d, max.P)):(i*min(d, max.P)),
                (1 + (i - 1)*min(d, max.P)):(i*min(d, max.P))] <- Sigma.block
      subject[(1 + (i - 1)*min(d, max.P)):(i*min(d, max.P))]   <- rep(i, min(d, max.P))
    }
    periods[[d]][[poss.n[length(poss.n)]]]         <- rep(1:min(d, max.P),
                                                          poss.n[length(poss.n)])
    subjects[[d]][[poss.n[length(poss.n)]]]        <- subject
    chol.Sigma.mats[[d]][[poss.n[length(poss.n)]]] <- chol(Sigma.mat)
    for (n in poss.n){
      periods[[d]][[n]]         <- periods[[d]][[poss.n[length(poss.n)]]][1:(n*min(d, max.P))]
      subjects[[d]][[n]]        <- subjects[[d]][[poss.n[length(poss.n)]]][1:(n*min(d, max.P))]
      chol.Sigma.mats[[d]][[n]] <- chol.Sigma.mats[[d]][[poss.n[length(poss.n)]]][1:(n*min(d, max.P)),
                                                                                  1:(n*min(d, max.P))]
      if (d == D){
        if (n%%d == 0){
          treatments[[n]]       <- treatments[[div.poss.n[length(div.poss.n)]]][1:(n*min(d, max.P))]
        }
      }
    }
  }

  if (summary == TRUE){
    print("Optimising over p and r. Messages from GenSA may follow...")
  }

  optimal.pilot <- GenSA(par = c(0.5, 0), fn = objFn, lower = c(0.25, 0),
                         upper = c(0.75, 2), control = list(max.call = max.calls,
                                                            verbose = summary),
                         max.o = max.o, D = D, E.tilde = E.tilde, max.P = max.P, alpha = alpha,
                         B = B, delta = delta, pi = pi, REML = REML,
                         t.boundaries = t.boundaries, design = design, periods = periods,
                         subjects = subjects, treatments = treatments,
                         chol.Sigma.mats = chol.Sigma.mats, replicates = replicates)
  optimal.p  <- optimal.pilot$par[1]
  optimal.r  <- optimal.pilot$par[2]
  optimal.ER <- -optimal.pilot$value

  if (summary == TRUE){
    print("Outputting results...")
  }

  output <- list(alpha = alpha, B = B, cpus = cpus, D = D, delta = delta,
                 E.tilde = E.tilde, max.calls = max.calls, max.O = max.O,
                 max.P = max.P,  optimal.ER = optimal.ER, optimal.p = optimal.p,
                 optimal.r = optimal.r, parallel = parallel, pi = pi,
                 REML = REML, replicates = replicates, sigma.b = sigma.b,
                 sigma.e = sigma.e, summary = summary,
                 t.boundaries = t.boundaries)
  return(output)
}
